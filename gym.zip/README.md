# PrimeFit Gym

## Setup

```bash
npm install
cp .env.example .env
npx prisma db push
npm run dev
```
