import type { Config } from 'tailwindcss'

export default {
  content: [
    "./app/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: 'var(--color-primary)',
        secondary: 'var(--color-secondary)',
        accent: 'var(--color-accent)',
        background: 'var(--color-background)',
        surface: 'var(--color-surface)',
      },
      fontFamily: {
        instrument: ['Instrument Serif', 'serif'],
        sans: ['Inter', 'sans-serif'],
      },
      spacing: {
        '128': '32rem',
      },
      animation: {
        grain: 'grain 10s linear infinite',
      },
      keyframes: {
        grain: {
          '0%': { transform: 'translate(0, 0)' },
          '100%': { transform: 'translate(-100%, -100%)' },
        },
      },
    },
  },
  plugins: [],
} satisfies Config