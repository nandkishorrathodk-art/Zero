/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  images: {
    // future-proof: allow any domain for now
    remotePatterns: [{ protocol: 'https', hostname: '**' }]
  }
};

export default nextConfig;