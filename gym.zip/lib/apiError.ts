export class ApiError extends Error {
  public statusCode: number
  public payload: Record<string, unknown>

  constructor(message: string, statusCode = 500, payload: Record<string, unknown> = {}) {
    super(message)
    this.statusCode = statusCode
    this.payload = payload
  }
}