// Placeholder for future auth/session utilities
export const getSession = async () => {
  // TODO: integrate next-auth or custom session logic
  return null;
};