import { useRef, useEffect } from 'react'
import { useFrame, extend, useThree } from '@react-three/fiber'
import { shaderMaterial } from '@react-three/drei'
import * as THREE from 'three'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

// ---------- GLSL ----------------------------------------------------
const vertexShader = `
precision highp float;
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`

const fragmentShader = `
precision highp float;
uniform vec2 resolution;
uniform vec2 mouse;
uniform float time;
uniform vec3 primaryColor;
uniform vec3 accentColor;
uniform vec3 backgroundColor;

varying vec2 vUv;

// 2D hash & noise -------------------------------------------------
float hash(vec2 p) {
  return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}

float noise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  float a = hash(i);
  float b = hash(i + vec2(1.0, 0.0));
  float c = hash(i + vec2(0.0, 1.0));
  float d = hash(i + vec2(1.0, 1.0));
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.y * u.x;
}

float fbm(vec2 p) {
  float value = 0.0;
  float amplitude = 0.5;
  for (int i = 0; i < 5; i++) {
    value += amplitude * noise(p);
    p *= 2.0;
    amplitude *= 0.5;
  }
  return value;
}

// Film grain -------------------------------------------------------
float grain(vec2 p) {
  return (hash(p + time * 10.0) - 0.5) * 0.2;
}

// ------------------------------------------------------------------
void main() {
  vec2 uv = vUv;

  // Mouse‑driven distortion
  vec2 md = (mouse - 0.5) * 0.15;
  uv += md;

  // Time‑based fbm distortion
  float d = fbm(uv * 3.0 + time * 0.05) * 0.02;
  uv += d;

  // Vertical gradient
  float t = smoothstep(0.0, 1.0, uv.y);
  vec3 grad = mix(primaryColor, accentColor, t);
  vec3 color = mix(backgroundColor, grad, 0.75);

  // Grain overlay
  color += grain(uv * resolution * 0.05);

  // Soft vignette
  float dist = distance(uv, vec2(0.5));
  color *= smoothstep(0.8, 0.5, dist);

  gl_FragColor = vec4(color, 1.0);
}
`

// ---------- Shader Material ---------------------------------------
const MyShaderMaterial = shaderMaterial(
  {
    time: 0,
    mouse: new THREE.Vector2(0.5, 0.5),
    resolution: new THREE.Vector2(0, 0),
    primaryColor: new THREE.Color('#1A1A1A'),
    accentColor: new THREE.Color('#D4AF37'),
    backgroundColor: new THREE.Color('#111111')
  },
  vertexShader,
  fragmentShader
)

extend({ MyShaderMaterial })

// ---------- React Component --------------------------------------
export const ShaderScene = () => {
  const materialRef = useRef<THREE.ShaderMaterial>(null)
  const meshRef = useRef<THREE.Mesh>(null)
  const { viewport, clock, mouse } = useThree()

  // Detect prefers-reduced-motion
  const prefersReduced = typeof window !== 'undefined' &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches

  useFrame(() => {
    if (!materialRef.current) return

    // Update uniforms each frame
    materialRef.current.uniforms.time.value = prefersReduced ? 0 : clock.getElapsedTime()

    // mouse is [-1,1] -> [0,1]
    materialRef.current.uniforms.mouse.value.set(
      (mouse.x + 1) * 0.5,
      (mouse.y + 1) * 0.5
    )

    materialRef.current.uniforms.resolution.value.set(viewport.width, viewport.height)
  })

  // Ensure dimensions are set on mount
  useEffect(() => {
    if (!materialRef.current) return
    materialRef.current.uniforms.resolution.value.set(viewport.width, viewport.height)
  }, [viewport])

  // ----- Scroll‑scrub camera (rotate plane to simulate camera movement) -----
  useEffect(() => {
    if (prefersReduced) return
    gsap.registerPlugin(ScrollTrigger)

    const tl = gsap.timeline({
      scrollTrigger: {
        trigger: '#shader-scene',
        start: 'top top',
        end: 'bottom bottom',
        scrub: true,
        pin: true
      }
    })

    tl.to(meshRef.current!.rotation, {
      y: Math.PI / 2,
      ease: 'none'
    })

    return () => tl.scrollTrigger?.kill()
  }, [prefersReduced])

  return (
    <mesh ref={meshRef} id="shader-scene">
      <planeGeometry args={[2, 2]} />
      <myShaderMaterial ref={materialRef} />
    </mesh>
  )
}