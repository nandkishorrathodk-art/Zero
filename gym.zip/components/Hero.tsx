"use client";
import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ShaderScene } from "@/components/ShaderScene";
import { Button } from "@/components/ui/Button";

export default function Hero() {
  const titleRef = useRef<HTMLHeadingElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);

  // Detect prefers-reduced-motion
  const prefersReduced = typeof window !== "undefined" &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  useEffect(() => {
    if (prefersReduced) return;

    const tl = gsap.timeline({ defaults: { ease: "power4.out" } });

    // Split title into words
    const words = titleRef.current?.textContent?.split(" ") ?? [];
    const wordSpans = words.map((w, i) => (
      <span key={i} className="hero-word inline-block overflow-hidden">
        {w}
      </span>
    ));

    // Replace title content with spans
    if (titleRef.current) {
      titleRef.current.innerHTML = "";
      wordSpans.forEach((span) => titleRef.current?.appendChild(span));
    }

    // Animate each word
    tl.from(
      ".hero-word",
      {
        clipPath: "inset(0 100% 0 0)",
        filter: "blur(20px)",
        opacity: 0,
        stagger: 0.15,
      },
      0
    );

    // CTA fade in
    tl.from(
      ctaRef.current,
      { opacity: 0, y: 20, duration: 0.6 },
      "-=0.4"
    );
  }, [prefersReduced]);

  return (
    <section className="relative w-full h-screen overflow-hidden">
      {/* WebGL background */}
      <div className="absolute inset-0">
        <ShaderScene />
      </div>

      {/* Content overlay */}
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-4">
        <h1
          ref={titleRef}
          className="text-6xl md:text-8xl font-instrument text-accent leading-tight tracking-tight"
        >
          PrimeFit Gym
        </h1>
        <Button
          ref={ctaRef}
          variant="primary"
          size="lg"
          className="mt-8"
        >
          Get Started
        </Button>
      </div>
    </section>
  );
}