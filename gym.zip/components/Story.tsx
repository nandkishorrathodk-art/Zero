"use client"
import { motion } from 'framer-motion'

export default function Story() {
  return (
    <section className="py-20 bg-background text-accent">
      <div className="max-w-5xl mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-4xl md:text-5xl font-instrument mb-8"
        >
          Unleash Your Potential
        </motion.h2>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.8 }}
          className="text-lg md:text-xl leading-relaxed"
        >
          PrimeFit Gym is a high‑end training studio that blends elite performance with a community‑centric culture. Our personalized programs, world‑class trainers, and state‑of‑the‑art facilities help you transform your body and mind. Join a community where every workout is tailored, every trainer is a coach, and every member sees measurable progress.
        </motion.p>
      </div>
    </section>
  )
}