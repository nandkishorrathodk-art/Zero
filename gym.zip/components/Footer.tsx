"use client"
import Link from 'next/link'

export default function Footer() {
  return (
    <footer className="bg-primary text-accent py-6 mt-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center">
        <p className="text-sm">&copy; {new Date().getFullYear()} PrimeFit Gym. All rights reserved.</p>
        <div className="flex space-x-4 mt-2 md:mt-0">
          <Link href="/terms" className="text-sm hover:text-white">
            Terms
          </Link>
          <Link href="/privacy" className="text-sm hover:text-white">
            Privacy
          </Link>
        </div>
      </div>
    </footer>
  )
}