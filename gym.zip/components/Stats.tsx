"use client"
import { motion } from 'framer-motion'

export default function Stats({ title, value }: { title: string; value: string }) {
  return (
    <motion.div
      className="flex flex-col items-center bg-surface p-6 rounded-lg shadow-sm"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <motion.span
        className="text-4xl font-instrument text-accent"
        whileHover={{ scale: 1.05 }}
      >
        {value}
      </motion.span>
      <span className="mt-2 text-sm text-accent/70">{title}</span>
    </motion.div>
  )
}