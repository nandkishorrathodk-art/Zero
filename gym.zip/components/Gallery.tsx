"use client"
import Image from 'next/image'
import { motion } from 'framer-motion'

const images = [
  '/gallery1.jpg',
  '/gallery2.jpg',
  '/gallery3.jpg',
  '/gallery4.jpg',
]

export default function Gallery() {
  return (
    <section className="py-20 bg-surface text-accent">
      <div className="max-w-6xl mx-auto px-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {images.map((src, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: i * 0.1 }}
            className="overflow-hidden rounded-lg"
          >
            <Image src={src} alt={`Gallery ${i + 1}`} width={400} height={300} className="object-cover w-full h-full" />
          </motion.div>
        ))}
      </div>
    </section>
  )
}