import { Table } from "@/components/ui/Table";
import { Button } from "@/components/ui/Button";

export function DataTable({ data }: { data: any[] }) {
  return (
    <Table>
      <thead>
        <tr>
          <th className="text-left">Title</th>
          <th className="text-left">Status</th>
          <th className="text-left">Updated</th>
          <th className="text-left">Actions</th>
        </tr>
      </thead>
      <tbody>
        {data.map((item) => (
          <tr key={item.id}>
            <td>{item.title}</td>
            <td>{item.status}</td>
            <td>{new Date(item.updatedAt).toLocaleDateString()}</td>
            <td>
              <Button variant="ghost" size="sm">
                Edit
              </Button>
            </td>
          </tr>
        ))}
      </tbody>
    </Table>
  );
}