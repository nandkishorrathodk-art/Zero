"use client"
import { useRef, useState } from 'react'
import { motion } from 'framer-motion'

export default function Magnet({ children, disabled = false }: any) {
  const [isActive, setIsActive] = useState(false)
  const [position, setPosition] = useState({ x: 0, y: 0 })
  const ref = useRef<HTMLDivElement>(null)

  const handleMouseMove = (e: any) => {
    if (disabled || !ref.current) return
    const { clientX, clientY } = e
    const { width, height, left, top } = ref.current.getBoundingClientRect()
    const middleX = clientX - (left + width / 2)
    const middleY = clientY - (top + height / 2)
    setPosition({ x: middleX * 0.1, y: middleY * 0.1 })
  }

  const reset = () => { setIsActive(false); setPosition({ x: 0, y: 0 }) }
  const handleMouseEnter = () => setIsActive(true)

  return (
    <motion.div ref={ref} onMouseMove={handleMouseMove} onMouseEnter={handleMouseEnter} onMouseLeave={reset}
      animate={{ x: position.x, y: position.y }} transition={{ type: "spring", stiffness: 150, damping: 15, mass: 0.1 }}>
      {children}
    </motion.div>
  )
}