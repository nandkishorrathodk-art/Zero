"use client";
import { ButtonHTMLAttributes, DetailedHTMLProps, useRef, useEffect } from "react";
import { clsx } from "clsx";
import { gsap } from "gsap";

type ButtonProps = DetailedHTMLProps<
  ButtonHTMLAttributes<HTMLButtonElement>,
  HTMLButtonElement
> & {
  variant?: "primary" | "secondary" | "ghost";
  size?: "sm" | "md" | "lg";
};

export function Button({
  variant = "primary",
  size = "md",
  className,
  ...props
}: ButtonProps) {
  const buttonRef = useRef<HTMLButtonElement>(null);

  // Detect prefers-reduced-motion
  const prefersReduced = typeof window !== "undefined" &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  useEffect(() => {
    if (prefersReduced) return;

    const el = buttonRef.current;
    if (!el) return;

    const handleEnter = () => {
      gsap.quickTo(el, "scale", { value: 1.05, duration: 0.2, ease: "power3.out" });
    };
    const handleLeave = () => {
      gsap.quickTo(el, "scale", { value: 1, duration: 0.2, ease: "power3.out" });
    };

    el.addEventListener("mouseenter", handleEnter);
    el.addEventListener("mouseleave", handleLeave);

    return () => {
      el.removeEventListener("mouseenter", handleEnter);
      el.removeEventListener("mouseleave", handleLeave);
    };
  }, [prefersReduced]);

  const base =
    "inline-flex items-center justify-center rounded-md font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2";

  const variants = {
    primary:
      "bg-accent text-white hover:bg-accent/90 focus:ring-accent",
    secondary:
      "bg-white/10 text-white hover:bg-white/20 focus:ring-white",
    ghost: "text-white hover:bg-white/10 focus:ring-white",
  };

  const sizes = {
    sm: "px-3 py-1.5 text-sm",
    md: "px-4 py-2 text-base",
    lg: "px-5 py-3 text-lg",
  };

  return (
    <button
      ref={buttonRef}
      data-magnet
      className={clsx(base, variants[variant], sizes[size], className)}
      {...props}
    />
  );
}