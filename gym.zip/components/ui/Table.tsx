"use client";
import { TableHTMLAttributes, DetailedHTMLProps } from "react";

export function Table({
  className,
  ...props
}: DetailedHTMLProps<TableHTMLAttributes<HTMLTableElement>, HTMLTableElement>) {
  return (
    <table
      className={clsx(
        "min-w-full divide-y divide-white/10",
        className
      )}
      {...props}
    />
  );
}