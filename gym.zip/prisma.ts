All files below are production‑ready TypeScript and ready to drop into a Next.js 14 project.  
**<thinking>** finished.  

---  

**File: prisma/schema.prisma**