"use client"
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // placeholder auth logic
    if (email === 'admin@example.com' && password === 'password') {
      router.push('/dashboard')
    } else {
      setError('Invalid credentials')
    }
  }

  return (
    <section className="min-h-screen flex items-center justify-center bg-background text-accent">
      <div className="max-w-md w-full bg-surface p-8 rounded-lg shadow-lg">
        <h1 className="text-3xl font-instrument mb-6 text-center">Login</h1>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full border border-surface rounded p-2 bg-primary text-accent focus:outline-none focus:ring-2 focus:ring-accent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full border border-surface rounded p-2 bg-primary text-accent focus:outline-none focus:ring-2 focus:ring-accent"
            />
          </div>
          {error && <p className="text-red-500 text-sm">{error}</p>}
          <motion.button
            type="submit"
            whileHover={{ scale: 1.02 }}
            className="w-full py-3 bg-accent text-primary rounded font-semibold hover:bg-accent/80 transition-colors"
          >
            Login
          </motion.button>
        </form>
      </div>
    </section>
  )
}