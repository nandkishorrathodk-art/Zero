import Proof from '@/components/Proof'
import Gallery from '@/components/Gallery'
import Stats from '@/components/Stats'

export default function MembershipPage() {
  return (
    <>
      <Proof />
      <Gallery />
      <section className="py-20 bg-surface text-accent">
        <div className="max-w-6xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-8">
          <Stats title="Premium Plans" value="$199/mo" />
          <Stats title="Personal Coaching" value="1:1" />
          <Stats title="24/7 Access" value="All Hours" />
        </div>
      </section>
    </>
  )
}