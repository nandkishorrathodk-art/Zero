import Hero from '@/components/Hero'
import Proof from '@/components/Proof'
import Story from '@/components/Story'

export default function Home() {
  return (
    <>
      <Hero />
      <Proof />
      <Story />
    </>
  )
}