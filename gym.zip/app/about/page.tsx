import Story from '@/components/Story'
import Gallery from '@/components/Gallery'

export default function AboutPage() {
  return (
    <>
      <Story />
      <Gallery />
    </>
  )
}