import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole } from '@/lib/auth'
import { ApiError } from '@/lib/apiError'

export async function POST(req: Request) {
  return await requireRole(req, async () => {
    const { type, url, altText, usage, style } = await req.json()

    if (!type || !url) {
      throw new ApiError('type and url are required', 400)
    }

    const media = await prisma.media.create({
      data: { type, url, altText, usage, style },
    })
    return NextResponse.json(media, { status: 201 })
  }, ['ADMIN'])
}