import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth } from '@/lib/auth'
import { ApiError } from '@/lib/apiError'

export async function GET() {
  const trainers = await prisma.trainer.findMany({
    include: { user: { select: { name: true, email: true } } },
  })
  return NextResponse.json(trainers)
}

export async function POST(req: Request) {
  return await requireAuth(req, async () => {
    const { bio, specialty, avatarUrl } = await req.json()
    const session = await requireAuth(req, async () => ({}))
    const userId = (session as any).sub

    // Convert user to trainer
    const trainer = await prisma.trainer.upsert({
      where: { userId },
      update: { bio, specialty, avatarUrl },
      create: {
        user: { connect: { id: userId } },
        bio,
        specialty,
        avatarUrl,
      },
    })
    return NextResponse.json(trainer, { status: 201 })
  })
}