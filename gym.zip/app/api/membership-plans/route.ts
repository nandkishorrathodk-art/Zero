import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth, requireRole } from '@/lib/auth'
import { ApiError } from '@/lib/apiError'

export async function GET() {
  const plans = await prisma.membershipPlan.findMany()
  return NextResponse.json(plans)
}

export async function POST(req: Request) {
  return await requireRole(req, async () => {
    const {
      title,
      description,
      priceCents,
      durationMonths,
      features,
    } = await req.json()

    if (!title || typeof title !== 'string') {
      throw new ApiError('Invalid title', 400)
    }

    const plan = await prisma.membershipPlan.create({
      data: {
        title,
        description,
        priceCents,
        durationMonths,
        features: features ?? [],
      },
    })
    return NextResponse.json(plan, { status: 201 })
  }, ['ADMIN'])
}