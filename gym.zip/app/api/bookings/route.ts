import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth } from '@/lib/auth'
import { ApiError } from '@/lib/apiError'

export async function GET(req: Request) {
  return await requireAuth(req, async () => {
    const session = await requireAuth(req, async () => ({}))
    const userId = (session as any).sub
    const role = (session as any).role as string

    let bookings
    if (role === 'TRAINER') {
      bookings = await prisma.booking.findMany({
        where: { trainerId: userId },
        include: { member: { select: { name: true } } },
      })
    } else {
      bookings = await prisma.booking.findMany({
        where: { memberId: userId },
        include: { trainer: { select: { user: { select: { name: true } } } } },
      })
    }
    return NextResponse.json(bookings)
  })
}

export async function POST(req: Request) {
  return await requireAuth(req, async () => {
    const { trainerId, scheduledAt } = await req.json()
    if (!trainerId || !scheduledAt) {
      throw new ApiError('trainerId and scheduledAt required', 400)
    }

    const session = await requireAuth(req, async () => ({}))
    const memberId = (session as any).sub

    // Verify trainer exists
    const trainer = await prisma.trainer.findUnique({
      where: { id: trainerId },
    })
    if (!trainer) {
      throw new ApiError('Trainer not found', 404)
    }

    const booking = await prisma.booking.create({
      data: {
        trainer: { connect: { id: trainerId } },
        member: { connect: { id: memberId } },
        scheduledAt: new Date(scheduledAt),
        status: 'BOOKED',
      },
    })
    return NextResponse.json(booking, { status: 201 })
  })
}