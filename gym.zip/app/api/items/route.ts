import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const items = await prisma.item.findMany({
    where: { ownerId: user.id },
    orderBy: { updatedAt: "desc" },
  });

  return NextResponse.json(items);
}

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await request.json();
  const { title, status } = body;

  if (!title || typeof title !== "string") {
    return NextResponse.json({ error: "Invalid or missing title" }, { status: 400 });
  }
  if (!status || typeof status !== "string") {
    return NextResponse.json({ error: "Invalid or missing status" }, { status: 400 });
  }

  const item = await prisma.item.create({
    data: {
      title,
      status,
      ownerId: user.id,
    },
  });

  return NextResponse.json(item, { status: 201 });
}