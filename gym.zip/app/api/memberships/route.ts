import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth } from '@/lib/auth'
import { ApiError } from '@/lib/apiError'

export async function GET(req: Request) {
  return await requireAuth(req, async () => {
    const session = await requireAuth(req, async () => ({}))
    const userId = (session as any).sub
    const memberships = await prisma.membership.findMany({
      where: { userId },
      include: { plan: true },
    })
    return NextResponse.json(memberships)
  })
}

export async function POST(req: Request) {
  return await requireAuth(req, async () => {
    const { planId } = await req.json()
    if (!planId) {
      throw new ApiError('planId is required', 400)
    }

    const session = await requireAuth(req, async () => ({}))
    const userId = (session as any).sub

    const plan = await prisma.membershipPlan.findUnique({
      where: { id: planId },
    })
    if (!plan) {
      throw new ApiError('Plan not found', 404)
    }

    const now = new Date()
    const end = new Date()
    end.setMonth(now.getMonth() + plan.durationMonths)

    const membership = await prisma.membership.create({
      data: {
        user: { connect: { id: userId } },
        plan: { connect: { id: planId } },
        status: 'ACTIVE',
        startDate: now,
        endDate: end,
      },
    })
    return NextResponse.json(membership, { status: 201 })
  })
}