import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET() {
  const items = await prisma.galleryItem.findMany({
    include: { media: true },
  })
  return NextResponse.json(items)
}