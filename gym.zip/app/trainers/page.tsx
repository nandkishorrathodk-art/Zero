import Story from '@/components/Story'
import Gallery from '@/components/Gallery'
import DataTable from '@/components/DataTable'

export default function TrainersPage() {
  const headers = ['Name', 'Specialty', 'Availability']
  const rows = [
    ['Alex Johnson', 'Strength', 'Mon, Wed, Fri'],
    ['Mia Lee', 'HIIT', 'Tue, Thu'],
    ['Carlos Ruiz', 'Yoga', 'Sat'],
  ]

  return (
    <>
      <Story />
      <Gallery />
      <section className="py-20 bg-surface text-accent">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-instrument mb-6 text-center">Trainer Schedule</h2>
          <DataTable headers={headers} rows={rows} />
        </div>
      </section>
    </>
  )
}