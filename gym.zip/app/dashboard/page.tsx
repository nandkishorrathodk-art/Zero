'use client';

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/Button";
import { DataTable } from "@/components/DataTable";

export default function Dashboard() {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchItems() {
      const res = await fetch("/api/items");
      if (res.ok) {
        const data = await res.json();
        setItems(data);
      }
      setLoading(false);
    }
    fetchItems();
  }, []);

  if (loading) return <p className="text-center py-12">Loading your progress...</p>;

  return (
    <section className="max-w-4xl mx-auto py-12">
      <h1 className="text-3xl font-semibold mb-6">Your Training Items</h1>
      <DataTable data={items} />
      <div className="mt-8 flex justify-end">
        <Button variant="primary">Add New Item</Button>
      </div>
    </section>
  );
}